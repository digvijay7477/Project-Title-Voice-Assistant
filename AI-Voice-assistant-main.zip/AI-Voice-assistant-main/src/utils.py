SCOPES = [
    "https://www.googleapis.com/auth/calendar.events",
    'https://www.googleapis.com/auth/contacts',
    "https://www.googleapis.com/auth/contacts.readonly"
]